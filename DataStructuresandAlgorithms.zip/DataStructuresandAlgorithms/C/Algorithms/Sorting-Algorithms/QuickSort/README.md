<h1 align=center>Quick Sort</h1>

#### NOTE: THE PROGRAM IS IN C 
</br>

Here's a brief about Quick sort. </br>


`Like merge sort, Quick sort is a divide and conquer algorithm.` </br>
`It picks an element as pivot and partition the given array around the picked pivot.` </br></br>


Now see the codes for proper understanding of Algorithm.</br></br>


### Contributed by:
[*Sarthak Luthra*](https://github.com/sarthak-21)