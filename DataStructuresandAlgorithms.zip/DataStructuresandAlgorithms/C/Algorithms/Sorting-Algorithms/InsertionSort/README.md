<h1 align=center>Insertion Sort</h1>

#### NOTE: THE PROGRAM IS IN C 
</br>

Here's a brief about Insertion sort. </br>

`The idea of this algorithm is to build your sorted array in place, shifting elements out of the way if necessary to make room as you go.` </br>

### Sample Input-1
```
4
34 21 43 56
```

### Sample Output
The sorted array is: </br>
`21 34 43 56`

### Sample Input-2
```
10
44 23 56 21 54 65 87 96 54 99
```

### Sample Output
The sorted array is: </br>
`21 23 44 54 54 56 65 87 96 99` </br></br>


Now see the codes for proper understanding of Algorithm.</br></br>


### Contributed by:
[*Sarthak Luthra*](https://github.com/sarthak-21)