## Go DataStructures and Algorithms

#### Testing
To run a test set the current working directory to the directory containing the test and use the command `go test`. 
For example to run the queue tests, head to `Data-Structures/queue` and run `go test`. 
