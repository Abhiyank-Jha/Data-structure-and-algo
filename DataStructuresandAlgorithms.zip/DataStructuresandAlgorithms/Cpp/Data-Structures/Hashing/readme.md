### Hashing
- [Trivial Hashing](trivial_hashing.cpp)

    trivial_hashing accesses an item by calculating the address of the table in which the item is stored by applying an arithmetic operation directly to the key value. 
    
    Time complexity = O(n)